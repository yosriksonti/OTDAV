<?php 
define('QUADODO_IN_SYSTEM', true);

use setasign\Fpdi\Fpdi;
use setasign\Fpdi\PdfReader;

require('fpdf/fpdf.php');
require('fpdi/src/autoload.php');


require_once('check.php');
require_once('includes/header.php');
if ($qls->user_info['group_id'] != '5' && $qls->user_info['group_id'] != '1') {
    header('Location: index.php');
}
include_once("config.php");

if(isset($_GET['ID']))
{
    $dpid=$_GET['ID'];
    $qt_namefr=" ";
    $dp_date=" ";
    $dp_titre=" ";
    $dp_desc=" ";
    $dp_auteur=" ";
    $dp_support=" ";
    $qt_date_c=" ";
    $qt_date_e=" ";
    $dp = mysqli_query($mysqli, "SELECT * FROM depot WHERE numero='".$dpid."'");
    $qt = mysqli_query($mysqli, "SELECT * FROM quitance WHERE id_depot='".$dpid."'");
    
    foreach($dp as $row)
        foreach($qt as $raw)
        {
            $qt_namefr=$raw['personne'];
            $dp_date=$row['date_sys'];
            $dp_titre=$row['titre_ouvre'];
            $dp_desc=$row['description'];
            $dp_auteur=$row['Auteur'];
            $dp_support=$row['support'];
            $qt_date_c=$raw['date_c'];
            $qt_date_e=$raw['date_e'];
        }
    
 
     

$pdf = new Fpdi();

$pageCount = $pdf->setSourceFile('pdf/demandefr.pdf');
$pageId = $pdf->importPage(1, PdfReader\PageBoundaries::MEDIA_BOX);

$pdf->addPage('P');
$pdf->useImportedPage($pageId, 0, 0, 297,420,true);
$pdf->SetFont('Arial','',12);

// depot
$pdf->Text(240,75,date('Y-m-d')); //Datein
$pdf->Text(146,228,$qt_namefr); //nomprenom

$pdf->Text(55,241,$dp_date); //Date_dp

$pdf->Text(130,241,$dpid); //nbr_dp

$pdf->Text(100,276,$dp_titre); //Titre_ov

$pdf->Text(115,253,$dp_desc); //Desc 

$pdf->Text(170,266,$dp_auteur); //Auteur

$pdf->Text(85,289,$dp_support); //Support

$pdf->Text(125,300,$qt_date_c);  //DU
$pdf->Text(175,300,$qt_date_e); //A
$pdf->Output('tmp/certificat/certificat-'.$dpid.'.pdf','F');
header('Location: validate_step2.php?ID='.$dpid);
    
  
}
?>