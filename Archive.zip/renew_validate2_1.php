<?php 
define('QUADODO_IN_SYSTEM', true);

use setasign\Fpdi\Fpdi;
use setasign\Fpdi\PdfReader;

require('fpdf/fpdf.php');
require('fpdi/src/autoload.php');


require_once('check.php');
require_once('includes/header.php');
if ($qls->user_info['group_id'] != '5' && $qls->user_info['group_id'] != '1') {
    header('Location: index.php');
}
include_once("config.php");

if(isset($_GET['ID']))
{
    $dpid=$_GET['ID'];
    $qt_namefr=" ";
    $dp_date=" ";
    $dp_titre=" ";
    $dp_desc=" ";
    $dp_auteur=" ";
    $dp_support=" ";
    $qt_date_c=" ";
    $qt_date_e=" ";
    $dp = mysqli_query($mysqli, "SELECT * FROM depot WHERE numero='".$dpid."'");
    $qt = mysqli_query($mysqli, "SELECT * FROM quitance WHERE id_depot='".$dpid."'");
    
    foreach($dp as $row)
        foreach($qt as $raw)
        {
            $qt_namefr=$raw['personne'];
            $dp_date=$row['date_sys'];
            $dp_titre=$row['titre_ouvre'];
            $dp_desc=$row['description'];
            $dp_auteur=$row['Auteur'];
            $dp_support=$row['support'];
            $qt_date_c=$raw['date_c'];
            $qt_date_e=$raw['date_e'];
        }
    
 
     

$pdf = new Fpdi();

$pageCount = $pdf->setSourceFile('pdf/redemandefr.pdf');
$pageId = $pdf->importPage(1, PdfReader\PageBoundaries::MEDIA_BOX);

$pdf->addPage('P');
$pdf->useImportedPage($pageId, 0, 0, 297,420,true);
$pdf->SetFont('Arial','',12);

// depot
$pdf->Text(240,70,date('Y-m-d')); //Datein
$pdf->Text(166,228,$qt_namefr); //nomprenom

$pdf->Text(55,241,date('d-m-Y')); //Date_dp

$pdf->Text(227,241,$dp_date); //nbr_dp

$pdf->Text(64,252,$dpid); //Titre_ov

$pdf->Text(160,264,$dp_auteur); //Auteur

$pdf->Text(100,276,$dp_titre); //Auteur
$pdf->Text(90,289,$dp_support); //Support
$pdf->Text(210,300,$qt_date_e); //A
$pdf->Output('tmp/certificat/certificat-'.$dpid.'-renouvellement.pdf','F');
header('Location: renew_validate2.php?ID='.$dpid);
    
  
}
?>