1. import image_uploads.sql to your database
2. change database credentials at the top of the upload.php
3. change $path variable to where you need to save the images
4. Run! 

(Don't forget to leave a comment in our website and share the tutorial)